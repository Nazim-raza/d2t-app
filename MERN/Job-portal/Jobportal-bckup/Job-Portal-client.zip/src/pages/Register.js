import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import InputForm from "../components/shared/InputForm";
import { useDispatch, useSelector } from "react-redux";
import { hideLoading, showLoading } from "../redux/features/alertSlice";
import axios from "axios";
import Spinner from "../components/shared/Spinner";
import { toast } from "react-toastify";

const Register = () => {
  const [name, setName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  //redux state
  const { loading } = useSelector((state) => state.alerts);

  //hooks
  const dispatch = useDispatch();
  const navigate = useNavigate();

  //=========== Without Reusable ===============
  // const [values, setValues] = useState({
  //   name: "",
  //   lastName: "",
  //   email: "",
  //   password: "",
  // });

  // //handle inputs
  // const handleChange = (e) => {
  //   const value = e.target.value;
  //   setValues({
  //     ...values,
  //     [e.target.name]: value,
  //   });
  // };

  //form function
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (!name || !lastName || !email || !password) {
        return toast.error("Please provide all fields");
      }
      dispatch(showLoading());
      const { data } = await axios.post("/api/v1/auth/register", {
        name,
        lastName,
        email,
        password,
      });
      dispatch(hideLoading());
      if (data.success) {
        toast.success("Registered Successfully");
        navigate("/login");
      }
      //console.log(name, lastName, email, password);
    } catch (error) {
      dispatch(hideLoading());
      toast.error("Invalid Form details");
      console.log(error);
      return;
    }
  };
  return (
    <>
      {loading ? (
        <Spinner />
      ) : (
        <div className="form-container">
          <form className="card p-4" onSubmit={handleSubmit}>
            <img src="/assets/images/logo/logo.png" alt="logo" />
            <InputForm
              htmlFor="name"
              lableText={"name"}
              type={"text"}
              value={name}
              handleChange={(e) => setName(e.target.value)}
            />
            <InputForm
              htmlFor="lastName"
              lableText={"lastName"}
              type={"text"}
              value={lastName}
              handleChange={(e) => setLastName(e.target.value)}
            />
            <InputForm
              htmlFor="email"
              lableText={"email"}
              type={"email"}
              value={email}
              handleChange={(e) => setEmail(e.target.value)}
            />
            <InputForm
              htmlFor="password"
              lableText={"password"}
              type={"password"}
              value={password}
              handleChange={(e) => setPassword(e.target.value)}
            />
            {/* <div className="mb-1">
            <label htmlFor="name" className="form-label">
              Name
            </label>
            <input type="text" className="form-control" name="name" />
          </div> */}
            {/* <div className="mb-1">
            <label htmlFor="name" className="form-label">
              Last Name
            </label>
            <input
              type="text"
              className="form-control"
              name="lastName"
              value={values.lastName}
              onChange={handleChange}
            />
          </div>
          <div className="mb-1">
            <label htmlFor="email" className="form-label">
              Email address
            </label>
            <input
              type="email"
              className="form-control"
              name="email"
              value={values.email}
              onChange={handleChange}
            />
          </div>
          <div className="mb-1">
            <label htmlFor="password" className="form-label">
              Password
            </label>
            <input
              type="password"
              className="form-control"
              name="password"
              value={values.password}
              onChange={handleChange}
            />
          </div> */}
            <div className="d-flex justify-content-between">
              <p>
                Already Register <Link to="/login">Login</Link>
              </p>
            </div>
            <button type="submit" className="btn btn-primary">
              Register
            </button>
          </form>
        </div>
      )}
    </>
  );
};

export default Register;

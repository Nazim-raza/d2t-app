import React, { useState } from 'react';
import UploadDocx from './components/UploadDocx';
import Layout1 from './templates/Layout1';
import Layout2 from './templates/Layout2';
import EduPageLayout from './templates/EduPageLayout';


function App() {
  const [convertedHtml, setConvertedHtml] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('layout1');

  const renderLayout = () => {
    if (!convertedHtml) return null;
  
    if (selectedTemplate === 'layout1') return <Layout1 html={convertedHtml} />;
    if (selectedTemplate === 'layout2') return <Layout2 html={convertedHtml} />;
    if (selectedTemplate === 'EduPageLayout') {
      return (
        <EduPageLayout
          title="1. Noun"
          content={convertedHtml}
          pageNumber={1}
        />
      );
    }
  
    return null;
  };
  
  const handleExport = () => {
    const element = document.querySelector(".edu-page"); // or your layout container class
  
    if (!element) {
      alert("No content found to export.");
      return;
    }
  
    import("html2pdf.js").then(html2pdf => {
      html2pdf.default()
        .from(element)
        .set({
          margin: 0,
          filename: "Converted-Layout.pdf",
          html2canvas: { scale: 2 },
          jsPDF: { unit: "pt", format: "a4", orientation: "portrait" },
        })
        .save();
    });
  };
  
  
  

  return (
    <div>
      <UploadDocx onUpload={setConvertedHtml} />

      <div className="container mt-4">
        <label>Select Layout:</label>
        <select
          className="form-select w-25"
          value={selectedTemplate}
          onChange={e => setSelectedTemplate(e.target.value)}
        >
          <option value="layout1">Layout 1 (Blue Theme)</option>
          <option value="layout2">Layout 2 (Peach Theme)</option>
          <option value="EduPageLayout">EduPageLayout</option>
        </select>
      </div>

      {renderLayout()}
      {convertedHtml && (
  <div className="container mt-4">
    <button className="btn btn-success" onClick={handleExport}>
      📄 Download as PDF
    </button>
  </div>
)}


      
    </div>
    
  );
}

export default App;

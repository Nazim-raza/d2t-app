import React from "react";
import "./EduPageLayout.css"; // custom styles

function EduPageLayout({ title, content, pageNumber }) {
  return (
    <div id="pdf-content" className="edu-page">
      {/* Header */}
      <div className="edu-header d-flex justify-content-between align-items-center px-3">
        <div className="fs-3 fw-bold">{title}</div>
        <div className="clouds">☁️☁️☁️</div>
      </div>

      {/* Content */}
      <div className="edu-content p-4">
        <div dangerouslySetInnerHTML={{ __html: content }} />
      </div>

      {/* Footer */}
      <div className="edu-footer d-flex justify-content-between px-4 py-2">
        <span className="fw-bold">Noun</span>
        <span>Page {pageNumber}</span>
      </div>
    </div>
  );
}

export default EduPageLayout;

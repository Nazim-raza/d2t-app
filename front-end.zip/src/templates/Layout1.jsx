import React from "react";

function Layout1({ html }) {
  return (
    <div className="p-5" style={{ background: "linear-gradient(#dfefff, #ffffff)" }}>
      <div className="border rounded p-4 shadow-lg bg-white">
        <div
          className="styled-html"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      </div>
    </div>
  );
}

export default Layout1;

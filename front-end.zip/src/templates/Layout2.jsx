import React from "react";

function Layout2({ html }) {
  return (
    <div className="p-5" style={{ background: "#fff8f0" }}>
      <div className="bg-light border-start border-5 border-info p-4 shadow">
        <div dangerouslySetInnerHTML={{ __html: html }} />
      </div>
    </div>
  );
}

export default Layout2;

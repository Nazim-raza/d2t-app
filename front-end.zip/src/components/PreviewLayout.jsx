import React from "react";
import "../PreviewLayout.css"; // optional custom styles

function PreviewLayout({ html }) {
  const createStyledHtml = () => {
    const container = document.createElement("div");
    container.innerHTML = html;

    // Style headings
    container.querySelectorAll("h1").forEach(h => {
      h.className = "text-primary fw-bold display-5 border-bottom pb-2";
    });

    container.querySelectorAll("h2").forEach(h => {
      h.className = "text-success fw-semibold h4 mt-4";
    });

    container.querySelectorAll("p").forEach(p => {
      p.className = "mb-3 fs-6";
    });

    container.querySelectorAll("ul").forEach(ul => {
      ul.className = "list-group list-group-flush mb-4";
      ul.querySelectorAll("li").forEach(li => {
        li.className = "list-group-item";
      });
    });

    container.querySelectorAll("table").forEach(table => {
      table.className = "table table-bordered table-striped mt-3";
    });

    return container.innerHTML;
  };

  return (
    <div className="container mt-5">
      <h3 className="mb-3 text-center">🧾 Converted & Styled Content</h3>
      <div
        className="p-4 bg-white border rounded shadow-sm"
        dangerouslySetInnerHTML={{ __html: createStyledHtml() }}
      />
    </div>
  );
}

export default PreviewLayout;

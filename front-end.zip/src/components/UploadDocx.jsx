import React, { useState } from 'react';

function UploadDocx({ onUpload }) {
  const [file, setFile] = useState(null);

  const handleChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = () => {
    if (!file) return alert("Please select a .docx file");

    const formData = new FormData();
    formData.append("docFile", file);

    fetch("http://localhost:5000/api/upload", {
      method: "POST",
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        onUpload(data.html);
      })
      .catch(err => {
        console.error(err);
        alert("Upload failed");
      });
  };

  return (
    <div className="container mt-4">
      <h3>Upload a .docx File</h3>
      <input type="file" className="form-control mb-2" onChange={handleChange} />
      <button className="btn btn-primary" onClick={handleUpload}>Upload & Convert</button>
    </div>
  );
}

export default UploadDocx;

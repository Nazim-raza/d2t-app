import React from 'react'
            
const Contact = () => {
    return (
        <div>
            <div className="footer">
                <h2>Contact Us</h2>
                <li>Email : nxtech.in.net@gmail.com</li>
                <li>Instagram : nxtechindia</li>
                <div className=''>
                <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSewcLJNOBNgitDhCwjDcfrgfJ1FRi2MPubVq7L_ygRTFEFszg/viewform?embedded=true" width="100%" height="1400" >Loading…</iframe>
            </div>
        </div>
        </div>
    )
}

export default Contact
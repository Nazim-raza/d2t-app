// server/index.js
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const mammoth = require('mammoth');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 5000;

// Middlewares
app.use(cors());
app.use(express.json());

// Multer setup
const upload = multer({ dest: 'uploads/' });

// Routes
app.post('/api/upload', upload.single('docFile'), async (req, res) => {
  try {
    const filePath = req.file.path;

    const result = await mammoth.convertToHtml({ path: filePath });
    const html = result.value;

    // Cleanup uploaded file
    fs.unlinkSync(filePath);

    res.json({ html });
  } catch (err) {
    console.error('Conversion error:', err);
    res.status(500).json({ error: 'Failed to convert file' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
